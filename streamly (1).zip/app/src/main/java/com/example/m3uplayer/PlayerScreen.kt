package com.example.m3uplayer

import android.app.Activity
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay

private fun timeText(ms: Long): String {
    if (ms <= 0) return "0:00"
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(vm: AppViewModel, items: List<Playable>, startIndex: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    var index by remember { mutableIntStateOf(startIndex.coerceIn(0, (items.size - 1).coerceAtLeast(0))) }
    val item = items[index]
    val isLive = item.isLive

    var error by remember { mutableStateOf<String?>(null) }
    var buffering by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var overlayTick by remember { mutableIntStateOf(0) }
    var showOverlay by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }

    // Un seul lecteur pour toute la séance : zapping et épisodes suivants instantanés
    val player = remember {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("IRPRO/1.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(20_000)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 60_000, 1_000, 2_500)
            .build()
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(context, http)))
            .setLoadControl(loadControl)
            .build()
    }

    val currentItem by rememberUpdatedState(item)

    fun saveNow() {
        val d = player.duration
        if (!currentItem.isLive && d != C.TIME_UNSET && d > 0) {
            vm.saveProgress(currentItem, player.currentPosition, d)
        }
    }

    // Lancement de chaque élément (avec reprise pour films / épisodes)
    LaunchedEffect(index) {
        error = null
        position = 0L
        duration = 0L
        player.setMediaItem(MediaItem.fromUri(item.url))
        val resumeAt = if (item.isLive) 0L else vm.savedPosition(item.key)
        if (resumeAt > 0) player.seekTo(resumeAt)
        player.prepare()
        player.playWhenReady = true
        item.channel?.let { vm.loadEpg(it) }
        overlayTick++
    }

    // Bandeau visible 4 s après chaque action
    LaunchedEffect(overlayTick) {
        showOverlay = true
        delay(4_000)
        if (player.isPlaying || isLive) showOverlay = false
    }

    // Position + sauvegarde régulière de la progression
    LaunchedEffect(Unit) {
        var tick = 0
        while (true) {
            delay(1_000)
            position = player.currentPosition
            val d = player.duration
            duration = if (d == C.TIME_UNSET || d < 0) 0L else d
            if (++tick % 10 == 0) saveNow()
        }
    }

    // Saisie d'un numéro de chaîne
    LaunchedEffect(digits) {
        if (digits.isEmpty()) return@LaunchedEffect
        delay(1_500)
        val n = digits.toIntOrNull()
        if (n != null && n in 1..items.size) index = n - 1
        digits = ""
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) {
                error = "Impossible de lire cette vidéo.\n(${e.errorCodeName})"
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_ENDED && !currentItem.isLive) {
                    // Fin : on note comme vu, puis épisode suivant s'il y en a un
                    val d = player.duration
                    if (d > 0) vm.saveProgress(currentItem, d, d)
                    if (index < items.size - 1) index++ else overlayTick++
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
        }
        player.addListener(listener)
        onDispose {
            saveNow()
            player.removeListener(listener)
            player.release()
        }
    }

    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    BackHandler(onBack = onBack)

    fun zap(delta: Int) {
        if (items.isEmpty()) return
        index = (index + delta + items.size) % items.size
    }

    fun seekBy(ms: Long) {
        val d = player.duration
        val target = (player.currentPosition + ms).coerceAtLeast(0L)
        player.seekTo(if (d > 0) target.coerceAtMost(d - 1_000) else target)
        position = player.currentPosition
        overlayTick++
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
        overlayTick++
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                val code = e.nativeKeyEvent.keyCode
                if (isLive) {
                    when {
                        e.key == Key.DirectionUp || e.key == Key.ChannelUp -> { zap(-1); true }
                        e.key == Key.DirectionDown || e.key == Key.ChannelDown -> { zap(1); true }
                        e.key == Key.DirectionCenter || e.key == Key.Enter -> { overlayTick++; true }
                        code in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> {
                            if (digits.length < 4) digits += (code - KeyEvent.KEYCODE_0).toString()
                            true
                        }
                        else -> false
                    }
                } else {
                    when {
                        e.key == Key.DirectionLeft || code == KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); true }
                        e.key == Key.DirectionRight || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(30_000); true }
                        e.key == Key.DirectionCenter || e.key == Key.Enter ||
                            code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePlay(); true }
                        e.key == Key.DirectionUp || e.key == Key.DirectionDown -> { overlayTick++; true }
                        code == KeyEvent.KEYCODE_MEDIA_NEXT && index < items.size - 1 -> { index++; true }
                        code == KeyEvent.KEYCODE_MEDIA_PREVIOUS && index > 0 -> { index--; true }
                        else -> false
                    }
                }
            }
            .focusable()
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    isFocusable = false
                    setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (buffering && error == null) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                IrProIcon(56.dp)
                Spacer(Modifier.height(12.dp))
                Text("Chargement…", color = Color(0xFFCCCCCC), fontSize = 18.sp)
            }
        }

        error?.let {
            Text(
                it + if (isLive) "\n\n▲ ▼ pour changer de chaîne" else "\n\nRetour pour revenir",
                color = Color.White,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        }

        if (digits.isNotEmpty()) {
            Text(
                digits,
                color = Color.White,
                fontSize = 52.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(36.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 22.dp, vertical = 8.dp)
            )
        }

        if (showOverlay) {
            if (isLive) {
                LiveOverlay(vm, item, index + 1, Modifier.align(Alignment.BottomCenter))
            } else {
                VodOverlay(
                    item, playing, position, duration,
                    hasNext = index < items.size - 1,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
private fun LiveOverlay(vm: AppViewModel, item: Playable, number: Int, modifier: Modifier) {
    val (now, next) = vm.nowNext(item.channel)
    val nowSec = System.currentTimeMillis() / 1000
    Row(
        modifier
            .fillMaxWidth()
            .background(Color(0xE608090B))
            .padding(horizontal = 44.dp, vertical = 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$number", color = PurpleLight, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(24.dp))
        item.channel?.let { ChannelLogo(it, 72) }
        Spacer(Modifier.width(22.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (now != null) {
                Text(
                    "${hhmm(now.start)} – ${hhmm(now.end)}  ·  ${now.title}",
                    color = PurpleLight, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                ProgressLine(now.progress(nowSec), Modifier.fillMaxWidth(0.7f), Color.White)
                if (next != null) {
                    Spacer(Modifier.height(4.dp))
                    Text("Ensuite ${hhmm(next.start)} : ${next.title}", color = TextSoft, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            } else {
                Text(item.subtitle, color = Color(0xFFBBBBBB), fontSize = 15.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.width(20.dp))
        Column(horizontalAlignment = Alignment.End) {
            Pill("● EN DIRECT", LiveRed, Color.White)
            Spacer(Modifier.height(8.dp))
            Text("▲ ▼ zapper  ·  chiffres  ·  OK infos", color = TextSoft, fontSize = 13.sp)
        }
    }
}

@Composable
private fun VodOverlay(
    item: Playable,
    playing: Boolean,
    position: Long,
    duration: Long,
    hasNext: Boolean,
    modifier: Modifier
) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Color(0xE608090B))
            .padding(horizontal = 44.dp, vertical = 22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.subtitle, color = PurpleLight, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                "◀ −10 s   OK lecture/pause   +30 s ▶" + if (hasNext) "   ⏭ épisode suivant" else "",
                color = TextSoft, fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(timeText(position), color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.width(14.dp))
            ProgressLine(
                if (duration > 0) position.toFloat() / duration else 0f,
                Modifier.weight(1f),
                PurpleMid
            )
            Spacer(Modifier.width(14.dp))
            Text(timeText(duration), color = Color.White, fontSize = 14.sp)
        }
    }
}
