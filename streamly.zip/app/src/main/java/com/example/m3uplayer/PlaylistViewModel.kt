package com.example.m3uplayer

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class PlaylistViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("m3u", Context.MODE_PRIVATE)
    private val cacheFile = File(app.filesDir, "playlist.m3u")

    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var loading by mutableStateOf(false)
        private set
    var errorMsg by mutableStateOf<String?>(null)
        private set
    var favorites by mutableStateOf(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
        private set
    var expiry by mutableStateOf(prefs.getString("expiry", null))
        private set

    /** "xtream" ou "m3u" */
    val mode: String get() = prefs.getString("mode", "xtream") ?: "xtream"
    val lastUrl: String get() = prefs.getString("url", "") ?: ""
    val savedServer: String get() = prefs.getString("xs", "") ?: ""
    val savedUser: String get() = prefs.getString("xu", "") ?: ""
    val savedPass: String get() = prefs.getString("xp", "") ?: ""

    init {
        if (cacheFile.exists()) {
            viewModelScope.launch {
                channels = withContext(Dispatchers.IO) { M3uParser.parse(cacheFile.readText()) }
                // Avec Xtream, on rafraîchit la liste en arrière-plan à chaque ouverture
                if (mode == "xtream" && savedServer.isNotBlank()) {
                    loadXtream(savedServer, savedUser, savedPass)
                }
            }
        }
    }

    fun loadXtream(server: String, user: String, pass: String) {
        val acc = XtreamAccount(XtreamClient.normalizeServer(server), user.trim(), pass.trim())
        prefs.edit()
            .putString("mode", "xtream")
            .putString("xs", acc.server)
            .putString("xu", acc.user)
            .putString("xp", acc.pass)
            .apply()
        var newExpiry: String? = null
        load(after = {
            expiry = newExpiry
            prefs.edit().putString("expiry", newExpiry).apply()
        }) {
            val info = XtreamClient.login(acc)
            newExpiry = info.expiry
            XtreamClient.toM3u(XtreamClient.liveChannels(acc))
        }
    }

    fun loadUrl(url: String) {
        prefs.edit().putString("mode", "m3u").putString("url", url).apply()
        load(after = { clearExpiry() }) { XtreamClient.httpGet(url) }
    }

    fun loadFile(uri: Uri) {
        prefs.edit().putString("mode", "m3u").apply()
        load(after = { clearExpiry() }) {
            getApplication<Application>().contentResolver.openInputStream(uri)
                ?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("Impossible de lire ce fichier")
        }
    }

    private fun clearExpiry() {
        expiry = null
        prefs.edit().remove("expiry").apply()
    }

    private fun load(after: () -> Unit = {}, fetch: () -> String) {
        viewModelScope.launch {
            loading = true
            errorMsg = null
            try {
                val list = withContext(Dispatchers.IO) {
                    val text = fetch()
                    val parsed = M3uParser.parse(text)
                    if (parsed.isEmpty()) throw IllegalStateException("Aucune chaîne trouvée")
                    cacheFile.writeText(text)
                    parsed
                }
                channels = list
                after()
            } catch (e: Exception) {
                errorMsg = e.message ?: "Erreur de chargement"
            } finally {
                loading = false
            }
        }
    }

    fun toggleFavorite(channel: Channel) {
        favorites = if (channel.url in favorites) favorites - channel.url else favorites + channel.url
        prefs.edit().putStringSet("favs", favorites).apply()
    }
}
