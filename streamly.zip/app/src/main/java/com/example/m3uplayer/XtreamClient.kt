package com.example.m3uplayer

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class XtreamAccount(val server: String, val user: String, val pass: String)

data class XtreamInfo(val status: String, val expiry: String?)

object XtreamClient {

    /** Accepte "serveur.com:8080", "http://serveur.com:8080/", ".../player_api.php"… */
    fun normalizeServer(raw: String): String {
        var s = raw.trim().trimEnd('/')
        s = s.removeSuffix("/player_api.php").removeSuffix("/get.php").trimEnd('/')
        if (!s.startsWith("http://", true) && !s.startsWith("https://", true)) s = "http://$s"
        return s
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(acc: XtreamAccount, action: String?): String {
        val url = "${acc.server}/player_api.php?username=${enc(acc.user)}&password=${enc(acc.pass)}" +
            (action?.let { "&action=$it" } ?: "")
        return httpGet(url)
    }

    fun httpGet(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "M3UPlayer/1.0")
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("Le serveur a répondu avec l'erreur $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    fun login(acc: XtreamAccount): XtreamInfo {
        val root = try {
            JSONObject(api(acc, null))
        } catch (e: Exception) {
            throw IllegalStateException("Ce serveur ne répond pas comme un serveur Xtream. Vérifie l'adresse.")
        }
        val ui = root.optJSONObject("user_info")
            ?: throw IllegalStateException("Identifiant ou mot de passe incorrect")
        if (ui.optInt("auth", 0) != 1) throw IllegalStateException("Identifiant ou mot de passe incorrect")
        val status = ui.optString("status")
        if (status.isNotBlank() && status != "null" && !status.equals("Active", ignoreCase = true)) {
            throw IllegalStateException("Abonnement non actif ($status)")
        }
        val expiry = ui.optString("exp_date").toLongOrNull()?.let {
            SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(it * 1000))
        }
        return XtreamInfo(status, expiry)
    }

    fun liveChannels(acc: XtreamAccount): List<Channel> {
        val catOrder = HashMap<String, Int>()
        val catNames = HashMap<String, String>()
        val cats = JSONArray(api(acc, "get_live_categories"))
        for (i in 0 until cats.length()) {
            val o = cats.optJSONObject(i) ?: continue
            val id = o.optString("category_id")
            catOrder[id] = i
            catNames[id] = o.optString("category_name").ifBlank { "Autres" }
        }

        val streams = JSONArray(api(acc, "get_live_streams"))
        val out = ArrayList<Channel>(streams.length())
        val catOfChannel = ArrayList<Int>(streams.length())
        for (i in 0 until streams.length()) {
            val o = streams.optJSONObject(i) ?: continue
            val id = o.optString("stream_id")
            if (id.isBlank() || id == "null") continue
            val catId = o.optString("category_id")
            val logo = o.optString("stream_icon").takeIf { it.isNotBlank() && it != "null" }
            out += Channel(
                name = o.optString("name").ifBlank { "Chaîne $id" },
                url = "${acc.server}/live/${acc.user}/${acc.pass}/$id.ts",
                logo = logo,
                group = catNames[catId] ?: "Autres"
            )
            catOfChannel += catOrder[catId] ?: Int.MAX_VALUE
        }
        // Trie par ordre des catégories du fournisseur (tri stable : garde l'ordre des chaînes)
        return out.indices.sortedBy { catOfChannel[it] }.map { out[it] }
    }

    /** Transforme la liste en texte M3U pour la garder en cache et la relire avec M3uParser. */
    fun toM3u(list: List<Channel>): String = buildString {
        appendLine("#EXTM3U")
        list.forEach { c ->
            append("#EXTINF:-1")
            c.logo?.let { append(" tvg-logo=\"").append(it.replace("\"", "")).append('"') }
            append(" group-title=\"").append(c.group.replace("\"", "")).append('"')
            append(',').appendLine(c.name.replace('\n', ' '))
            appendLine(c.url)
        }
    }
}
