package com.example.m3uplayer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage

// Couleurs de l'appli
val Teal = Color(0xFF1D9E75)
val TealLight = Color(0xFF5DCAA5)
val Bg = Color(0xFF0E1013)
val Panel = Color(0xFF15181D)
val CardBg = Color(0xFF1C2026)
val TextMain = Color(0xFFF1EFE8)
val TextSoft = Color(0xFF9A9A9A)

private const val ALL = "Toutes les chaînes"
private const val FAVS = "Favoris"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Teal,
                    background = Bg,
                    surface = Panel,
                    onSurface = TextMain,
                    onBackground = TextMain
                )
            ) {
                App()
            }
        }
    }
}

@Composable
fun App(vm: PlaylistViewModel = viewModel()) {
    var playing by remember { mutableStateOf<Pair<List<Channel>, Int>?>(null) }
    var showSource by remember { mutableStateOf(false) }
    val current = playing

    Box(Modifier.fillMaxSize().background(Bg)) {
        if (current != null) {
            PlayerScreen(current.first, current.second, onBack = { playing = null })
        } else {
            HomeScreen(
                vm = vm,
                onPlay = { list, i -> playing = list to i },
                onSource = { showSource = true }
            )
        }
    }
    if (showSource) AddSourceDialog(vm, onDismiss = { showSource = false })
}

/** Élément sélectionnable à la télécommande : grossit et s'entoure de vert quand il a le focus. */
@Composable
fun FocusBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(12.dp),
    selected: Boolean = false,
    onFocused: () -> Unit = {},
    content: @Composable BoxScope.(focused: Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.04f else 1f, label = "focusScale")
    Box(
        modifier
            .scale(scale)
            .clip(shape)
            .background(
                when {
                    focused -> Teal
                    selected -> CardBg
                    else -> Color.Transparent
                }
            )
            .border(2.dp, if (focused) TealLight else Color.Transparent, shape)
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocused()
            }
            .clickable(onClick = onClick)
    ) {
        content(focused)
    }
}

@Composable
fun Logo(channel: Channel, size: Int) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size / 5).dp)).background(CardBg),
        contentAlignment = Alignment.Center
    ) {
        if (channel.logo != null) {
            AsyncImage(
                model = channel.logo,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding((size / 10).dp)
            )
        } else {
            Text(
                channel.name.split(" ").mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString(""),
                color = TealLight,
                fontSize = (size / 3).sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun HomeScreen(vm: PlaylistViewModel, onPlay: (List<Channel>, Int) -> Unit, onSource: () -> Unit) {
    val channels = vm.channels
    val favorites = vm.favorites
    val groups = remember(channels) { listOf(ALL, FAVS) + channels.map { it.group }.distinct() }
    var group by rememberSaveable { mutableStateOf(ALL) }
    var focusedChannel by remember { mutableStateOf<Channel?>(null) }
    val firstFocus = remember { FocusRequester() }

    val shown = remember(channels, group, favorites) {
        channels.filter {
            when (group) {
                ALL -> true
                FAVS -> it.url in favorites
                else -> it.group == group
            }
        }
    }

    // Met le focus sur le premier élément dès que l'écran s'affiche
    LaunchedEffect(channels.isEmpty()) {
        runCatching { firstFocus.requestFocus() }
    }

    Column(Modifier.fillMaxSize()) {
        // Barre du haut
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = TextMain)) { append("Stream") }
                    withStyle(SpanStyle(color = TealLight)) { append("ly") }
                },
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.weight(1f))
            vm.expiry?.let {
                Text("Abonnement jusqu'au $it", color = TextSoft, fontSize = 14.sp)
                Spacer(Modifier.width(20.dp))
            }
            FocusBox(onClick = onSource, shape = RoundedCornerShape(24.dp)) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Settings, contentDescription = null, tint = TextMain)
                    Spacer(Modifier.width(8.dp))
                    Text("Source", color = TextMain)
                }
            }
        }

        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Teal)
        vm.errorMsg?.let {
            Text(it, color = Color(0xFFF09595), modifier = Modifier.padding(horizontal = 32.dp, vertical = 8.dp))
        }

        if (channels.isEmpty() && !vm.loading) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Bienvenue sur Streamly", color = TextMain, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("Connecte ton compte Xtream Codes ou ajoute un lien M3U.", color = TextSoft, fontSize = 18.sp)
                Spacer(Modifier.height(28.dp))
                FocusBox(
                    onClick = onSource,
                    modifier = Modifier.focusRequester(firstFocus),
                    shape = RoundedCornerShape(28.dp),
                    selected = true
                ) {
                    Text(
                        "Se connecter",
                        color = TextMain,
                        fontSize = 20.sp,
                        modifier = Modifier.padding(horizontal = 36.dp, vertical = 14.dp)
                    )
                }
            }
            return@Column
        }

        Row(Modifier.fillMaxSize()) {
            // Catégories
            LazyColumn(
                Modifier.width(240.dp).fillMaxHeight().background(Panel),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                itemsIndexed(groups) { i, g ->
                    FocusBox(
                        onClick = { group = g },
                        onFocused = { group = g },
                        selected = g == group,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().then(if (i == 0) Modifier.focusRequester(firstFocus) else Modifier)
                    ) { focused ->
                        Text(
                            g,
                            color = if (focused || g == group) TextMain else TextSoft,
                            fontSize = 16.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }

            // Chaînes
            LazyColumn(
                Modifier.weight(1f).fillMaxHeight(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (shown.isEmpty()) {
                    item {
                        Text(
                            if (group == FAVS) "Aucun favori pour l'instant. Sélectionne le cœur à droite d'une chaîne."
                            else "Aucune chaîne dans cette catégorie.",
                            color = TextSoft,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                itemsIndexed(shown) { i, c ->
                    val isFav = c.url in favorites
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FocusBox(
                            onClick = { onPlay(shown, i) },
                            onFocused = { focusedChannel = c },
                            modifier = Modifier.weight(1f)
                        ) { focused ->
                            Row(
                                Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "${i + 1}",
                                    color = if (focused) TextMain else TextSoft,
                                    fontSize = 15.sp,
                                    modifier = Modifier.width(44.dp)
                                )
                                Logo(c, 44)
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, color = TextMain, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        c.group,
                                        color = if (focused) TextMain.copy(alpha = 0.8f) else TextSoft,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        FocusBox(
                            onClick = { vm.toggleFavorite(c) },
                            onFocused = { focusedChannel = c },
                            shape = RoundedCornerShape(28.dp)
                        ) { focused ->
                            Icon(
                                if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = if (isFav) "Retirer des favoris" else "Ajouter aux favoris",
                                tint = when {
                                    focused -> TextMain
                                    isFav -> Color(0xFFF09595)
                                    else -> TextSoft
                                },
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }
                }
            }

            // Aperçu de la chaîne sélectionnée
            val previewChannel = focusedChannel ?: shown.firstOrNull()
            PreviewPanel(
                channel = previewChannel,
                isFavorite = previewChannel != null && previewChannel.url in favorites,
                modifier = Modifier.width(320.dp).fillMaxHeight()
            )
        }
    }
}

@Composable
fun PreviewPanel(channel: Channel?, isFavorite: Boolean, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel).padding(28.dp)) {
        if (channel != null) {
            Logo(channel, 120)
            Spacer(Modifier.height(20.dp))
            Text(channel.name, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(channel.group, color = TealLight, fontSize = 15.sp)
            if (isFavorite) {
                Spacer(Modifier.height(8.dp))
                Text("Dans tes favoris", color = Color(0xFFF09595), fontSize = 14.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("OK  ·  regarder", color = TextSoft, fontSize = 14.sp)
        Text("→ puis OK sur le cœur  ·  favori", color = TextSoft, fontSize = 14.sp)
        Text("Dans le lecteur : ▲ ▼ ou chiffres pour zapper", color = TextSoft, fontSize = 14.sp)
    }
}

@Composable
fun AddSourceDialog(vm: PlaylistViewModel, onDismiss: () -> Unit) {
    var mode by remember { mutableStateOf(vm.mode) }
    var url by remember { mutableStateOf(vm.lastUrl) }
    var server by remember { mutableStateOf(vm.savedServer) }
    var user by remember { mutableStateOf(vm.savedUser) }
    var pass by remember { mutableStateOf(vm.savedPass) }
    var pickerError by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            vm.loadFile(uri)
            onDismiss()
        }
    }
    val isXtream = mode == "xtream"
    val canSubmit = if (isXtream) server.isNotBlank() && user.isNotBlank() && pass.isNotBlank() else url.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Ajouter une source", color = TextMain) },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isXtream, onClick = { mode = "xtream" }, label = { Text("Xtream Codes") })
                    FilterChip(selected = !isXtream, onClick = { mode = "m3u" }, label = { Text("Lien M3U") })
                }
                Spacer(Modifier.height(12.dp))
                if (isXtream) {
                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it },
                        label = { Text("Serveur") },
                        placeholder = { Text("http://serveur.com:8080") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        label = { Text("Identifiant") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = pass,
                        onValueChange = { pass = it },
                        label = { Text("Mot de passe") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("Lien M3U") },
                        placeholder = { Text("http://exemple.com/playlist.m3u") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = {
                        // Certaines box n'ont pas de sélecteur de fichiers
                        pickerError = runCatching { picker.launch(arrayOf("*/*")) }.isFailure
                    }) { Text("Ou choisir un fichier .m3u") }
                    if (pickerError) {
                        Text("Cette box ne permet pas de choisir un fichier. Utilise un lien.", color = Color(0xFFF09595), fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = canSubmit, onClick = {
                if (isXtream) vm.loadXtream(server, user, pass) else vm.loadUrl(url.trim())
                onDismiss()
            }) { Text(if (isXtream) "Se connecter" else "Charger") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
